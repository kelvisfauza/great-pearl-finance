# Great Pearl Finance — Supabase + React

A real, working Finance Department web app for Great Pearl Coffee. Built with **Vite + React + TypeScript + Tailwind + Supabase**.

## Features
- Create/list **Payments** and **Expenses** (Supabase CRUD + realtime refresh)
- **Approvals**: approve/reject updates status and timestamps
- **Receive Coffee Pricing**: publish prices to `finance_prices`
- **Statements**: reads `finance_ledgers` (if present) or computes a simple running balance from Payments/Expenses
- **Reports**: export CSV (payments & expenses)
- **Printable receipts** for payments (client-side `window.print()`)
- Basic **Auth**: email OTP (magic link)

## Quickstart

1. **Create a Supabase project** and copy your URL and anon key.
2. **Run the SQL bootstrap** (in Supabase → SQL Editor):

   See [`supabase.sql`](./supabase.sql). It creates the `finance_prices`, `finance_payments`, `finance_expenses`, and `finance_ledgers` tables and enables simple RLS (any authenticated user).

3. **Clone & install**

   ```bash
   npm install
   ```

4. **Configure env**

   Create `.env.local` (or export as shell vars) with:

   ```bash
   VITE_SUPABASE_URL=your_supabase_url
   VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
   ```

5. **Run**

   ```bash
   npm run dev
   ```

6. **Sign in** (optional): enter your email in the top-right and click **Sign in** to receive a magic link.

## Deploy
- Push this repo to GitHub.
- For Vercel/Netlify/etc., set the same env vars (`VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`).

## Notes
- This repo uses minimal custom UI (Tailwind) for portability. You can later swap in shadcn/ui components.
- The ledger fallback is simplistic (payments/expenses as debits). Replace with proper accounting as needed.
- To generate server PDFs and store them in Supabase Storage, add an API route and link it to the “Receipt” action.

